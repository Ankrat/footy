'use strict';

angular.module('footyApp.view1', ['ngRoute'])
.controller('LoginController', LoginController);

function LoginController($scope){
  // Instantiate persistant object
  $scope.master = {};

  // Copy input into master
  $scope.update = function(user) {
    $scope.master = angular.copy(user);
  };

  // Empty $scope.user
  $scope.reset = function() {
    $scope.user = {};

    // Reset master ??
    // $scope.master = {};

    // Or keep logs
    // push master to an array???
  };

  // empty $scope.user on load
  $scope.reset();
};